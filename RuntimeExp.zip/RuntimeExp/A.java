package RuntimeExp;
public class A
{
    public void printName()
    {
        System.out.println("Hello Nidhi\n Hello Abhijeet\n Hello Shuruti");
    }
}